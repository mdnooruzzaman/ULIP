window['getConfig'] = {  API_URL:'http://127.0.0.1:5000/'}


// http://192.168.99.38/ECommAnomaly/
// http://127.0.0.1:5000/