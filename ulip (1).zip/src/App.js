import logo from './logo.svg'
import './App.css'
import Homepage from './Components/Homepage'
import Login from './Components/Login'
import MainLogin from './Components/MainLogin'
import React, { useEffect } from 'react'
import { apiRequest } from './Service'

// window.addEventListener('storage', () => {
//   // When local storage changes, dump the list to
//   // the console.
//   console.log(JSON.parse(window.localStorage.getItem('UPLoggedIn')));
//   if(JSON.parse(window.localStorage.getItem('UPLoggedIn')) == null){
//       window.location.reload();
//   }
// });

window.addEventListener('storage', () => {
  if (
    JSON.parse(window.localStorage.getItem('UPLoggedIn')) == null ||
    JSON.parse(window.localStorage.getItem('UPLoggedIn')) == false ||
    window.localStorage.getItem('UPLoggedIn') == 'false'
  ) {
    console.log(JSON.parse(window.localStorage.getItem('UPLoggedIn')))
    if (localStorage.getItem('ulipweb-loggedout') == 'true') {
      window.location.reload()
      localStorage.setItem('ulipweb-loggedout', 'false')
    } else if (localStorage.getItem('ulipuser-loggedout') == 'true') {
      window.location.reload()
      localStorage.setItem('ulipuser-loggedout', 'false')
    }
  }
})

function App () {
  const [userID, setUserID] = React.useState('')
  useEffect(() => {
    loginValidation()
  }, [])

  const loginValidation = async () => {

    
    let clean_uri
    let address = document.location.search
    console.log('address', address)
    let parameterList = new URLSearchParams(address)
    console.log('parameterList', parameterList)
    let map = new Map()
    parameterList.forEach((value, key) => {
      map[key] = value
    })
    console.log('map', map)
    // localStorage.setItem("ulip-UPUserID", map["userid"]);
    // localStorage.setItem("ulip-UPUser", map["emailid"]);
    clean_uri = map['id']

    const api = 'validateuser'
    const formData = new FormData()
    formData.append('id', clean_uri)
    const response = await apiRequest(api, formData)
    console.log(response.data)
    if (response.data.status == 'success') {
      localStorage.setItem('ulip-UPUser', response.data.email)
      localStorage.setItem('ulip-UPUserID', response.data.userid)
      setUserID(response.data.email)
      // window.location.reload();
    }
  }
  console.log("localStorage.getItem('UPLoggedIn') ",localStorage.getItem('UPLoggedIn')  )
  console.log("localStorage.getItem('ulip-UPUser')", localStorage.getItem('ulip-UPUser'))
  console.log("localStorage.getItem('ulip-WebUserMailID')", localStorage.getItem('ulip-WebUserMailID'))
  console.log(localStorage.getItem('ulip-UPUser') == localStorage.getItem('ulip-WebUserMailID'))
  console.log((localStorage.getItem('UPLoggedIn') !== null &&
  (localStorage.getItem('ulip-UPUser') !== null &&
  localStorage.getItem('ulip-WebUserMailID') !== null
    ? localStorage.getItem('ulip-UPUser') ==
      localStorage.getItem('ulip-WebUserMailID')
      ? true
      : false
    : false)))
  return (
    <>
   { (localStorage.getItem('UPLoggedIn') !== null &&
    (localStorage.getItem('ulip-UPUser') !== null &&
    localStorage.getItem('ulip-WebUserMailID') !== null
      ? localStorage.getItem('ulip-UPUser') ==
        localStorage.getItem('ulip-WebUserMailID')
        ? true
        : false
      : false)) ? (
    <Homepage />
  ) : (
    <div className='MainAPP'>
      <h4
        className='m-5 NotFoundTxt text-danger'
        id='NotFoundTxt'
        style={{ textAlign: 'center' }}
      >
        404 - Not Found!
      </h4>
    </div>
  )}
    </>
  )

}

export default App
