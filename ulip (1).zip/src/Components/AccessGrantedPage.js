import React, { Component } from "react";
import {
  AppBar,
  Grid,
  TextField,
  InputAdornment,
  IconButton,
} from "@material-ui/core";
import { Button } from "react-bootstrap";
import "./css/AccessGrantedPage.css";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { withStyles } from "@material-ui/core/styles";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import { styled, useTheme } from "@mui/material/styles";
import CloseIcon from "@mui/icons-material/Close";
import { RoomSharp, ThreeSixtyOutlined } from "@material-ui/icons";
import { apiRequest } from "../Service";
import searchIcon from "./img/search.svg";
import { ThirtyFpsSelect } from "@mui/icons-material";

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: "#6A7F9B38",
  },
  "&:nth-of-type(even)": {
    backgroundColor: "#6A7F9B21",
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#7A9298",
    textAlign: "left",
    font: "normal normal normal 14px/21px Poppins !important",
    letterSpacing: "0px",
    color: "#FFFFFF",
    opacity: 1,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    background: "#90AAB1 0% 0% no-repeat padding-box",
    opacity: 0.31,
    textAlign: "left",
    font: "normal normal normal 14px/21px Poppins !important",
    letterSpacing: "0px",
    color: "#4B5B68",
    opacity: 1,
  },
}));

const styles = (theme) => ({
  header: {
    borderRadius: "8px",
  },
  headerRow: {
    background: "#7B93A7 0% 0% no-repeat padding-box",
    borderRradius: "4px",
    opacity: 1,
    position: "sticky",
    top: 0,
  },
  bodyRows: {
    background: "#ffffff 0% 0% no-repeat padding-box",
  },
  bodyRows: {
    background: "#ffffff 0% 0% no-repeat padding-box",
  },
  headerRowCell: {
    font: "normal normal normal 14px/21px Poppins !important",
    letterSpacing: "0px",
    color: "#FFFFFF",
    background: "#7B93A7",
    borderRradius: "4px",
    opacity: 1,
    textAlign: "left",
  },
  bodyRowCell: {
    textAlign: "left",
    font: "normal normal normal 14px/21px Poppins !important",
    letterSpacing: "0px",
    color: "#4B5B68",
    opacity: 1,
  },
  tableNameColCel: {
    textAlign: "left",
    font: "normal normal bold 14px/21px Poppins !important",
    letterSpacing: "0px",
    color: "#052A46",
    opacity: 1,
    verticalAlign: "initial",
  },
  txtRejected: {
    color: "rgb(244, 71, 71)",
    textAlign: "left",
    font: "normal normal 600 14px/21px Poppins",
    letterSpacing: "0px",
    opacity: 1,
  },
  txtInProgressApproval: {
    color: "#009FFF",
    textAlign: "left",
    font: "normal normal 600 14px/21px Poppins",
    letterSpacing: "0px",
    opacity: 1,
  },
  txtInProgressReview: {
    color: "rgb(175, 175, 9)",
    textAlign: "left",
    font: "normal normal 600 14px/21px Poppins",
    letterSpacing: "0px",
    opacity: 1,
  },
  txtApproved: {
    color: "rgb(25, 164, 25)",
    textAlign: "left",
    font: "normal normal 600 14px/21px Poppins",
    letterSpacing: "0px",
    opacity: 1,
  },
  txtLink: {
    color: "#007bff",
    textDecoration: "underline",
    cursor: "pointer",
  },
});

class AccessGrantedPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      requestCount:
        sessionStorage.getItem("ulip-UPRequestCount") !== null
          ? JSON.parse(sessionStorage.getItem("ulip-UPRequestCount"))
          : 0,
      requestedData: [],
      filteredData: [],
      dialogOpen: false,
      selectedRequestIDIndex: null,
      createRequestAPIErr: false,
      enableRequestsTable: false,
      getrequestsAPIErr: false,
    };
    this.requestedDataDetails = this.requestedDataDetails.bind(this);
    this.openRequestDetails = this.openRequestDetails.bind(this);
    this.getRequestHistory = this.getRequestHistory.bind(this);
    this.onsearchFilter = this.onsearchFilter.bind(this);
  }

  componentDidMount() {
    this.getRequestHistory();
  }

  getRequestHistory = async () => {
    this.props.enableLoader(true);
    this.setState({ getrequestsAPIErr: false });
    const api = "getrequests";
    const formData = new FormData();
    formData.append("userid", localStorage.getItem("ulip-UPUserID"));
    const response = await apiRequest(api, formData);
    console.log("getrequests response", response.data);
    setTimeout(() => {
      this.props.enableLoader(false);
    }, 1500);
    if (response.data.status == "success") {
      response.data.requests != undefined &&
        response.data.requests.map((eachRequest, requestIndex) => {
          eachRequest.json_data = JSON.parse(eachRequest.json_data);
        });

      this.setState(
        {
          requestedData: response.data.requests,
          filteredData: response.data.requests,
        },
        () => {
          this.setState({
            enableRequestsTable:
              response.data.requests != undefined ? true : false,
            requestCount:
              response.data.requests != undefined
                ? response.data.requests.length
                : null,
          });
          console.log("requestedData", this.state.requestedData);
          sessionStorage.setItem(
            "ulip-UPRequestedData",
            JSON.stringify(this.state.requestedData)
          );
        }
      );
      response.data.requests != undefined && sessionStorage.setItem(
        "ulip-UPRequestCount",
        response.data.requests.length
      );
    } else {
      console.log("else block");
      this.setState({ getrequestsAPIErr: true, enableRequestsTable: false });
    }
  };

  openRequestDetails = (requestIDIndex) => {
    this.setState({ selectedRequestIDIndex: requestIDIndex }, () => {
      console.log("requested Id index", this.state.selectedRequestIDIndex);
      this.setState({ dialogOpen: true });
    });
  };

  requestedDataDetails = () => {
    const { classes } = this.props;
    return (
      <>
        <Grid container className={"AG-RquestedTableMainDiv"} md={12}>
          <Grid item className={"AG-RequestedTableSubDiv"} md={12}>
            <p className={"AG-RequestedID mb-0"}>
              Request ID:{" "}
              {
                this.state.requestedData[this.state.selectedRequestIDIndex][
                  "req_id"
                ]
              }
            </p>
            <CloseIcon
              style={{ cursor: "pointer" }}
              onClick={() => {
                this.setState({ dialogOpen: false });
              }}
            />
          </Grid>
          <Grid item md={12}>
            <hr className={"AG-hrTag"}></hr>
          </Grid>
          <Grid item md={(Object.keys(
                this.state.requestedData[this.state.selectedRequestIDIndex][
                  "json_data"
                ]
              )).length != 1 ? 5 : 12}>
            <div className={"requestDetails"}>
              <p className="col-md-6 p-0 mb-3 requestSubDetails">
                {" "}
                Requested Date :
              </p>
              <p className="col-md-6 p-0 mb-3 requestedDate">
                {
                  this.state.requestedData[this.state.selectedRequestIDIndex][
                    "created_at"
                  ]
                }
              </p>
            </div>
            <div className={"requestDetails"}>
              <p className="col-md-6 p-0 mb-3 requestSubDetails"> Status :</p>
              <p
                className={
                  this.state.requestedData[this.state.selectedRequestIDIndex][
                    "approver_verified"
                  ] == "submitted"
                    ? "col-md-6 p-0 mb-3 txtInProgressApproval"
                    : this.state.requestedData[
                        this.state.selectedRequestIDIndex
                      ]["approver_verified"] == "submitted"
                    ? "col-md-6 p-0 mb-3 txtInProgressApproval"
                    : this.state.requestedData[
                        this.state.selectedRequestIDIndex
                      ]["approver_verified"] == "approved"
                    ? "col-md-6 p-0 mb-3 txtApproved"
                    : this.state.requestedData[
                        this.state.selectedRequestIDIndex
                      ]["approver_verified"] == "rejected"
                    ? "col-md-6 p-0 mb-3 txtRejected"
                    : ""
                }
              >
                {
                  this.state.requestedData[this.state.selectedRequestIDIndex][
                    "approver_verified"
                  ]
                }
              </p>
            </div>
          </Grid>
          <Grid container md={12} className={"eachTableMainGrid"} spacing={2}>
            {Object.keys(
              this.state.requestedData[this.state.selectedRequestIDIndex][
                "json_data"
              ]
            ).map((eachTable, tableIndex) => (
              <Grid
                item
                md={(Object.keys(
                  this.state.requestedData[this.state.selectedRequestIDIndex][
                    "json_data"
                  ]
                )).length != 1 ? 5 : 12}
                key={tableIndex}
                className={"eachTableGrid mt-4 ml-2"}
              >
                <p className={"tableTitle pl-2 mb-1"}>{eachTable}</p>
                <TableContainer
                  style={{
                    width: "100%",
                    height: "200px",
                    maxHeight: "200px",
                    borderRadius: "6px",
                  }}
                  className={"AG-TableContainerDiv"}
                >
                  <Table
                    size="small"
                    className={"AG-TableClass"}
                    stickyHeader={true}
                    aria-label="sticky table"
                  >
                    <TableHead className={classes.header}>
                      <TableRow style={{ position: "sticky", top: 0 }}>
                        <TableCell
                          className={[classes.headerRowCell, "col-md-4"]}
                          colSpan={4}
                          align="left"
                        >
                          Table Column Name
                        </TableCell>
                        <TableCell
                          className={classes.headerRowCell}
                          colSpan={4}
                          align="left"
                        >
                          Status
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.keys(
                        this.state.requestedData[
                          this.state.selectedRequestIDIndex
                        ].json_data[eachTable]
                      ).map((eachColumnName, eachColumnNameIndex) => (
                        <StyledTableRow
                          key={eachColumnNameIndex}
                          className={classes.bodyRows}
                        >
                          <StyledTableCell
                            className={classes.tableNameColCel}
                            colSpan={4}
                            align="left"
                          >
                            {eachColumnName}
                          </StyledTableCell>
                          <StyledTableCell
                            // className={
                            //   this.state.requestedData[
                            //     this.state.selectedRequestIDIndex
                            //   ].json_data[eachTable][eachColumnName] ==
                            //   "submitted"
                            //     ? [classes.txtInProgressApproval]
                            //     : this.state.requestedData[
                            //         this.state.selectedRequestIDIndex
                            //       ].json_data[eachTable][eachColumnName] ==
                            //       "approved"
                            //     ? [classes.txtApproved]
                            //     : this.state.requestedData[
                            //         this.state.selectedRequestIDIndex
                            //       ].json_data[eachTable][eachColumnName] ==
                            //       "rejected"
                            //     ? [classes.txtRejected]
                            //     : ""
                            // }
                            colSpan={4}
                            align="left"
                          >
                            {
                              this.state.requestedData[
                                this.state.selectedRequestIDIndex
                              ].json_data[eachTable][eachColumnName]
                            }
                          </StyledTableCell>
                        </StyledTableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>
            ))}
          </Grid>
        </Grid>
      </>
    );
  };

  onsearchFilter = (e) => {
    let filterString = e.target.value;
    let tempData = [...this.state.requestedData];
    console.log("filterString", filterString);
    console.log("tempData", tempData);
    let filteredData = [];
    filteredData = tempData.filter((item, itemIndex) =>
      Object.keys(item).some(
        (eachCol) =>
          (eachCol == "req_id" ||
            eachCol == "created_at" ||
            eachCol == "approver_verified") &&
          item[eachCol]
            .toString()
            .toLowerCase()
            .includes(filterString.toLowerCase())
      )
    );
    console.log("filteredData", filteredData);
    this.setState({ filteredData: filteredData });
    // setViewData(filteredData);
    // setSearchString(e.target.value);
  };

  render() {
    const { classes } = this.props;
    console.log(typeof this.state.requestCount);
    return (
      <>
        <div container className={"AccessGrantedMainDiv p-3"} md={12}>
          {this.state.dialogOpen && (
            <Dialog
              className={"dialogMain p-2"}
              open={true}
              aria-labelledby="form-dialog-title"
              id= {(Object.keys(
                this.state.requestedData[this.state.selectedRequestIDIndex][
                  "json_data"
                ]
              )).length != 1 ? 'dialogMainID' : 'dailogSingleContent'}
            >
              <DialogContent
                className={"p-4 col-md-12"}
                style={{ textAlignLast: "center" }}
              >
                {this.requestedDataDetails()}
              </DialogContent>
            </Dialog>
          )}

          <Grid item className={"AG-SubDiv"} md={12}>
            <Grid className="AG-SubDivTitleGrid">
              <p className={"AG-Title mb-0"}>
                Access Granted{" "}
                {this.state.enableRequestsTable &&
                  "(" + this.state.requestCount + ")"}
              </p>

              {this.state.enableRequestsTable && (
                <Button
                  className="newRequestButton"
                  onClick={this.props.goToRequestPage}
                >
                  + Add A New Request
                </Button>
              )}
            </Grid>

            <hr className={"AG-hrTag"}></hr>
            {this.state.enableRequestsTable ? (
              <>
                
                  <>
                    <Grid md={12} className={"requestAccessSearchFieldSubGrid"}>
                      {" "}
                      <TextField
                        variant="outlined"
                        type={"text"}
                        margin="normal"
                        id="companyName"
                        autoComplete="off"
                        size="small"
                        aria-readonly
                        className={"searchDataFieldStyle mt-1 mb-2"}
                        placeholder="Search Data"
                        name="companyName"
                        onChange={this.onsearchFilter}
                        height="0.4em"
                        InputProps={{
                          startAdornment: (
                            <InputAdornment>
                              <IconButton className="searchIconBtn">
                                <img
                                  className={"registerIconImg"}
                                  src={searchIcon}
                                />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Grid>

                    {this.state.filteredData.length ? (
                        <Grid item md={10} className={"mt-2"}>
                      <TableContainer
                        style={{
                          maxHeight: "400px",
                          overflow: "scroll",
                        }}
                        elevation={3}
                        className={"AG-TableContainerDiv "}
                      >
                        <Table
                          size="small"
                          className={"AG-TableClass"}
                          stickyHeader={true}
                          aria-label="sticky table"
                        >
                          <TableHead className={classes.header}>
                            <TableRow style={{ position: "sticky", top: 0 }}>
                              <TableCell
                                className={[classes.headerRowCell, "col-md-2"]}
                                colSpan={2}
                                align="left"
                              >
                                #SL.No
                              </TableCell>
                              <TableCell
                                className={[classes.headerRowCell, "col-md-4"]}
                                colSpan={4}
                                align="left"
                              >
                                Request ID
                              </TableCell>
                              <TableCell
                                className={classes.headerRowCell}
                                colSpan={4}
                                align="left"
                              >
                                Requested Date
                              </TableCell>
                              <TableCell
                                className={classes.headerRowCell}
                                colSpan={4}
                                align="left"
                              >
                                Request Status
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {this.state.filteredData.map(
                              (eachRow, rowIndex) => (
                                <TableRow
                                  key={rowIndex}
                                  className={classes.bodyRows}
                                >
                                  <TableCell
                                    className={classes.bodyRowCell}
                                    colSpan={2}
                                  >
                                    {rowIndex + 1}
                                  </TableCell>
                                  <TableCell
                                    colSpan={4}
                                    className={[
                                      classes.bodyRowCell,
                                      classes.txtLink,
                                    ]}
                                    onClick={() => {
                                      this.openRequestDetails(rowIndex);
                                    }}
                                  >
                                    {eachRow["req_id"]}
                                  </TableCell>
                                  <TableCell
                                    colSpan={4}
                                    className={classes.bodyRowCell}
                                  >
                                    {eachRow["created_at"]}
                                  </TableCell>
                                  <TableCell
                                    colSpan={4}
                                    className={
                                      eachRow["approver_verified"] == "rejected"
                                        ? [
                                            classes.bodyRowCell,
                                            classes.txtRejected,
                                          ]
                                        : eachRow["approver_verified"] ==
                                          "submitted"
                                        ? [
                                            classes.bodyRowCell,
                                            classes.txtInProgressApproval,
                                          ]
                                        : eachRow["approver_verified"] ==
                                          "approved"
                                        ? [
                                            classes.bodyRowCell,
                                            classes.txtApproved,
                                          ]
                                        : [
                                            classes.bodyRowCell,
                                            classes.txtRejected,
                                          ]
                                    }
                                    align="left"
                                  >
                                    {eachRow["approver_verified"]}
                                  </TableCell>
                                </TableRow>
                              )
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Grid>

                ) : (
                  <p>No Data Found</p>
                )}
                                  </>
              </>
            ) : (
              <>
                <p className={"AG-RequestNotAccessedMsg"}>
                  No data access is granted to user yet.
                </p>
                <Button
                  className={"AG-RequestAccessBtn"}
                  onClick={this.props.goToRequestPage}
                >
                  Click Here To Request Data Access
                </Button>

                {this.state.createRequestAPIErr && (
                  <p className="errMsg">An internal server error occurred. Please try again!</p>
                )}
              </>
            )}

            {this.state.getrequestsAPIErr && (
              <p className="errMsg">An internal server error occurred. Please try again!</p>
            )}
          </Grid>
        </div>
      </>
    );
  }
}

export default withStyles(styles, { withTheme: true })(AccessGrantedPage);
