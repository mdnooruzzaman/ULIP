import React, { Component } from "react";
import {
  AppBar,
  makeStyles,
  Grid,
  Typography,
  Button,
  TextField,
  InputAdornment,
  IconButton,
  FormControlLabel,
  Checkbox,
  Divider,
} from "@material-ui/core";
import NativeSelect from "@material-ui/core/NativeSelect";
import InputBase from "@material-ui/core/InputBase";
import { withStyles } from "@material-ui/core/styles";
import emailVerified from "./img/verified.svg";
import indiaFlag from "./img/india-flag.png";
import OtpInput from "react-otp-input";
import personInactive from "./img/username.svg";
import personActive from "./img/username_active.svg";
import pinCodeInactive from "./img/pin_code_inactive.png";
import pinCodeActive from "./img/pin_code_active.png";
import webActive from "./img/web_active.svg";
import emailActive from "./img/business_email_active.svg";
import emailInactive from "./img/business_email_inactive.svg";
import companyActive from "./img/company_active.svg";
import "./css/CompanyDetails.css";
import CloudUploadIcon from "./img/upload.svg";
import EditIcon from "@material-ui/icons/Edit";
import Badge from "@material-ui/core/Badge";
import { styled, useTheme } from "@mui/material/styles";
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip";
import InfoIcon from "@mui/icons-material/Info";
import { apiRequest } from "../Service";

const BootstrapTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} arrow classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.arrow}`]: {
    color: "#739dbd",
  },
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: "#739dbd",
  },
}));

const BootstrapInput = withStyles((theme) => ({
  input: {
    backgroundColor: "#F5F6F6",
    borderRadius: 4,
    position: "relative",
    background: "#FAFAFA 0% 0% no-repeat padding-box",
    border: "1px solid #ced4da",
    padding: "11px 26px 11px 12px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    textAlign: "left",
    font: "normal normal normal 14px/18px Poppins",
    letterSpacing: "0px",
    color: "#050A30",
    opacity: "1",
    "&:focus": {
      borderRadius: 4,
      border: "2px solid #1D669E",
    },
  },
}))(InputBase);


class CompanyDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userDetails: sessionStorage.getItem("ulip-UPUserDetails") !== null ? JSON.parse(sessionStorage.getItem("ulip-UPUserDetails")) : []
    };

    this.requestDataAccess = this.requestDataAccess.bind(this);
    this.onFormFieldChange = this.onFormFieldChange.bind(this);
  }  

  onFormFieldChange = (event) => {
    // console.log("id", event.target.id);
    let onlyStringWithSpaceFormat = /^[a-zA-Z ]*$/;
    let emailIDFormat =
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let websiteURLFormat =
      /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
    let indianMobileNumberFormat = /^[789]\d{9}$/;
    let onlyAlphaNumericFormat = /^(?=.*\d)(?=.*[a-zA-Z]).{2,}$/;
    if (event.target.id == "companyName") {
      this.setState(
        {
          companyName: event.target.value,
          companyNameErr: false,
        },
        () => {
          this.setState(
            {
              companyNameErr:
                (onlyAlphaNumericFormat.test(event.target.value) ||
                  onlyStringWithSpaceFormat.test(event.target.value)) &&
                this.state.companyName.length > 3 &&
                this.state.companyName.length < 30
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    } else if (event.target.id == "companyWebsite") {
      this.setState(
        {
          companyWebsite: event.target.value,
          companyWebsiteErr: false,
        },
        () => {
          this.setState(
            {
              companyWebsiteErr:
                this.state.companyWebsite.length >= 13 &&
                websiteURLFormat.test(this.state.companyWebsite)
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    } else if (event.target.id == "companyType") {
      this.setState(
        {
          selectedCompanyType: event.target.value,
        },
        () => {
          this.setState(
            {
              companyTypeErr:
                this.state.selectedCompanyType.length >= 1 ? false : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    } else if (event.target.id == "officeBuildingNo") {
      this.setState(
        {
          companyBuildingNo: event.target.value,
          companyBuildingNoErr: false,
        },
        () => {
          this.setState(
            {
              companyBuildingNoErr:
                this.state.companyBuildingNo.length >= 2 &&
                this.state.companyBuildingNo.length <= 10
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    } else if (event.target.id == "officeArea") {
      this.setState(
        {
          companyAreaName: event.target.value,
          companyAreaNameErr: false,
        },
        () => {
          this.setState(
            {
              companyAreaNameErr:
                (onlyAlphaNumericFormat.test(this.state.companyAreaName) ||
                  onlyStringWithSpaceFormat.test(this.state.companyAreaName)) &&
                this.state.companyAreaName.length >= 4 &&
                this.state.companyAreaName.length <= 25
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    }
    // else if (event.target.id == "state") {
    //   let selectedStateObj = [
    //     ...this.state.states.filter(
    //       (item, index) => item.name == event.target.value
    //     )
    //   ];
    //   let countryCode = selectedStateObj[0]["countryCode"];
    //   let isoCode = selectedStateObj[0]["isoCode"];

    //   let Cities = City.getCitiesOfState(countryCode, isoCode);
    //   let forDadraState = [{ name: "Dadra and Nagara Haveli" }];
    //   this.setState(
    //     {
    //       state: event.target.value,
    //       cities: isoCode == "DH" ? forDadraState : Cities
    //     },
    //     () => {
    //       this.formFinalCheck();
    //     }
    //   );
    // }
    // else if (event.target.id == "city") {
    //   this.setState(
    //     {
    //       city: event.target.value
    //     },
    //     () => {
    //       this.formFinalCheck();
    //     }
    //   );
    // }
    else if (event.target.id == "pinCode") {
      this.setState(
        {
          pinCode: event.target.value,
        },
        () => {
          this.setState(
            {
              pinCodeErr:
                this.state.pinCode.length == 6 && this.state.pinCode > 0
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
        }
      );
    } else if (event.target.id == "emailID") {
      this.setState(
        {
          emailID: event.target.value,
          emailVerify: false,
          emailIDErr: false,
          enableOTPField: false,
          OTP: "",
          resentOTP: false,
          enableValidateOTPBtn: false,
          emailValidated: false,
          emailValidateSpinner: false,
          OTPResendSpinner: false,
          OTPErr: false,
        },
        () => {
          // if (this.state.emailID.length >= 1) {
          let domain = this.state.emailID.split("@")[1];
          // console.log(domain);
          this.setState(
            {
              emailVerify:
                emailIDFormat.test(this.state.emailID) &&
                domain.indexOf("gmail") == -1 &&
                domain.indexOf("gmail") == -1
                  ? true
                  : false,
            },
            () => {
              this.setState({ emailIDErr: !this.state.emailVerify });
            }
          );
          // }
        }
      );
    } else if (event.target.id == "personName") {
      this.setState(
        {
          personName: event.target.value,
          personNameErr: false,
        },
        () => {
          // console.log(
          //   "company name match",
          //   onlyStringWithSpaceFormat.test(event.target.value)
          // );
          // if (this.state.personName.length >= 1) {
          this.setState(
            {
              personNameErr:
                onlyStringWithSpaceFormat.test(event.target.value) &&
                this.state.personName.length > 3 &&
                this.state.personName.length < 25
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
          // }
        }
      );
    } else if (event.target.id == "mobileNo") {
      this.setState(
        {
          mobileNo: event.target.value,
          mobileNoErr: false,
        },
        () => {
          // console.log(
          //   "company name match",
          //   indianMobileNumberFormat.test(event.target.value)
          // );
          // if (this.state.mobileNo.length >= 1) {
          this.setState(
            {
              mobileNoErr:
                indianMobileNumberFormat.test(event.target.value) &&
                this.state.mobileNo.length == 10
                  ? false
                  : true,
            },
            () => {
              this.formFinalCheck();
            }
          );
          // }
        }
      );
    }
  };
  onFormFieldFocus = (event) => {
    console.log("id", event.target.id);
    if (event.target.id == "companyName") {
      this.setState({
        companyNameIcon: companyActive,
      });
    } else if (event.target.id == "companyWebsite") {
      this.setState({
        companyWebsiteIcon: webActive,
      });
    } else if (event.target.id == "pinCode") {
      this.setState({
        pinCodeIcon: pinCodeActive,
      });
    } else if (event.target.id == "emailID") {
      this.setState({
        emailIDIcon: emailActive,
      });
    } else if (event.target.id == "personName") {
      this.setState({
        personIcon: personActive,
      });
    }
  };

  componentDidMount(){
    this.requestDataAccess();
  }

  requestDataAccess = async () => {
    // if(!(JSON.parse(sessionStorage.getItem("ulip-UPRequestCount")) >= 1)){
      // this.setState({ createRequestAPIErr: false });
      const api = "createrequest";
      const formData = new FormData();
      formData.append("userid", localStorage.getItem("ulip-UPUserID"));
      const response = await apiRequest(api, formData);
      console.log("createrequest response", response.data);
      if (response.data.status === "success") {
        console.log("if block");
        this.setState({userDetails : response.data.userDetails[0]})
        sessionStorage.setItem(
          "ulip-UPUserDetails",
          JSON.stringify(response.data.userDetails[0])
        );
      } else {
        console.log("else block");
        this.setState({ createRequestAPIErr: true });
      }
    // }
  };

  render() {
    return (
      <div className="CompanyDetailsMainDiv">
        <Grid md={12} className={"companyDetailsTitle"}>
          <p className="companyDetailsTitleName">
            <Badge badgeContent={1} color="primary" className="mr-4"></Badge>{" "}
            Company Details
          </p>
        </Grid>
        <Grid container md={12} className={"mainFormGrid"} spacing={1}>
          <Grid item md={4} className="pt-0 subEachFieldGrid">
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Company Name
            </label>
            <TextField
              disabled
              variant="outlined"
              type={"text"}
              margin="normal"
              fullWidth
              id="companyName"
              autoComplete="off"
              size="small"
              aria-readonly
              value={this.state.userDetails.companyname}
              className={"registerFieldStyle mt-1 mb-2"}
              name="companyName"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 registerFormLabels"
              id="registerFieldInputs mt-2 "
            >
              Nature Of Business
            </label>
            <TextField
              disabled
              variant="outlined"
              type={"text"}
              margin="normal"
              fullWidth
              id="companyName"
              autoComplete="off"
              size="small"
              aria-readonly
              value={this.state.userDetails.companytype}
              className={"registerFieldStyle mt-1 mb-2"}
              name="companyName"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 registerFormLabels"
              id="registerFieldInputs mt-2 "
            >
              Registered Office
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"text"}
              margin="normal"
              fullWidth
              id="officeArea"
              autoComplete="off"
              size="small"
              aria-readonly
              value={
                this.state.userDetails.officebuildingnumber + ", " +
                this.state.userDetails.officeareaname + ", " +
                this.state.userDetails.city + ", " +
                this.state.userDetails.state 
              }
              className={"registerFieldStyle mt-1 mb-2"}
              name="officeArea"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Website
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"url"}
              margin="normal"
              fullWidth
              id="companyWebsite"
              autoComplete="off"
              size="small"
              aria-readonly
              value={this.state.userDetails.companywebsite}
              className={"registerFieldStyle mt-1 mb-2"}
              name="companyWebsite"
              height="0.4em"
            />
          </Grid> 
          <Grid item md={4} className="pt-0 subEachFieldGrid">
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Contact Person Name
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"text"}
              margin="normal"
              fullWidth
              id="personName"
              autoComplete="off"
              size="small"
              aria-readonly
              value={this.state.userDetails.contactpersonname}
              className={"registerFieldStyle mt-1 mb-2"}
              name="personName"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Mobile Number
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"number"}
              margin="normal"
              fullWidth
              id="mobileNo"
              autoComplete="off"
              size="small"
              aria-readonly
              value={this.state.userDetails.mobilenumber}
              className={"registerFieldStyle mt-1 mb-2"}
              name="mobileNo"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Official Email ID
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"text"}
              margin="normal"
              fullWidth
              id="emailID"
              autoComplete="off"
              size="small"
              value={this.state.userDetails.emailid}
              className={"registerFieldStyle mt-1 mb-2"}
              name="emailID"
              height="0.4em"
            />
          </Grid>
          <Grid item md={4} className={"pt-0 subEachFieldGrid"}>
            <label
              htmlFor="my-input"
              className="mb-n5 pt-0 registerFormLabels"
              id="registerFieldInputs"
            >
              Public IP
            </label>
            <TextField
            disabled
              variant="outlined"
              type={"url"}
              margin="normal"
              fullWidth
              id="companyWebsite"
              autoComplete="off"
              size="small"
              aria-readonly
              // value={"http://192.168.99.38"}
              value={this.state.userDetails.ip_address}
              className={"registerFieldStyle mt-1 mb-2"}
              name="companyWebsite"
              height="0.4em"
            />
          </Grid>
          <Grid
            item
            md={12}
            className="companyDetailsCheckBoxDiv"
            style={{ display: "flex" }}
          >
            <Grid item md={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={true}
                    name="companyDetailsApproval"
                    size="small"
                    className="companyDetailsCheckBox"
                  />
                }
                className="companyDetailsFormControlLabel p-0"
                label="I accept Terms & Conditions to mentioned in the attached NDA and agree to execute the NDA prior getting access to the data."
              />
            </Grid>

            {/* <Grid item md={1} className="InfoIconMainDiv">
              <BootstrapTooltip
                id="tooltipStepper"
                arrow={true}
                placement={"right"}
                title="Until & unless check the agreed check box user can not submit the request"
                disableFocusListener
                style={{ margin: " 12px 0px 5px 12px" }}
                className="BootstrapToolTipclass"
              >
                <InfoIcon
                  style={{ color: "#739dbd!", verticalAlign: "sub" }}
                  fontSize="small"
                />
              </BootstrapTooltip>
            </Grid> */}



          </Grid>
        </Grid>
      </div>
    );
  }
}

export default CompanyDetails;
