import React, { Component } from "react";
import "./css/CompanyDocuments.css";
import {
  Grid,
  TextField,
  InputAdornment,
  FormControlLabel,
  Checkbox,
  Button,
} from "@material-ui/core";
// import "./css/Register.css";
import personInactive from "./img/username.svg";
import pinCodeInactive from "./img/pin_code_inactive.png";
import webInactive from "./img/web_inactive.svg";
import emailInactive from "./img/business_email_inactive.svg";
import CloudUploadIcon from "./img/upload.svg";
import companyInactive from "./img/company_inactive.svg";
import DescriptionIcon from "@material-ui/icons/Description";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import CancelIcon from "@material-ui/icons/Cancel";
import Captcha from "demos-react-captcha";
import Badge from "@material-ui/core/Badge";

const companyType = [
  {
    id: 1,
    name: "Facility Management",
  },
  {
    id: 2,
    name: "Public Utility",
  },
  {
    id: 3,
    name: "Residential Services",
  },
  {
    id: 4,
    name: "Electrical Energy / Distribution",
  },
  {
    id: 5,
    name: "Transportation",
  },
  {
    id: 6,
    name: "Trades",
  },
  {
    id: 7,
    name: "Food Services",
  },
];

class CompanyDocuments extends Component {
  constructor(props) {
    super(props);
    this.state = {
      POA: "",
      POAErr: false,
      companyProfile: "",
      companyProfileErr: false,
      DDOUseCase: "",
      DDOUseCaseErr: false,
      SAC: "",
      SACErr: false,
      isCaptcha: false,
      DPIITRecognizedStartUp: false,
      POADocument: null,
      SACDocument: null,
      DDOUseCaseDocument: null,
      POAErrMsg: "",
      DDOErrMsg: "",
      SACErrMsg: "",
    };
    this.onBrowseFile = this.onBrowseFile.bind(this);
    this.enableNextSection = this.enableNextSection.bind(this);
  }

  onBrowseFile = (event) => {
    let fileExtension = event.target.files[0].name.split(".", 2).pop();
    if (event.target.id == "POA") {
      this.setState(
        {
          POA: event.target.files[0].name,
          POADocument: fileExtension === "pdf" ? event.target.files[0] : null,
        },
        () => {
          if (fileExtension === "pdf") {
            let POASize = this.state.POADocument.size;
            POASize = (POASize * 0.0000009537).toPrecision(2);
            this.setState({
              POAErr:
                this.state.POA.length >= 1 && !(POASize > 3) ? false : true,
              POAErrMsg:
                POASize > 3
                  ? "The file exceeds the maximum upload size(3MB) limit"
                  : "",
            });
          } else {
            this.setState({
              POAErr: true,
              POAErrMsg: "Please upload valid file format(PDF)!",
            });
          }
        }
      );
      sessionStorage.setItem("ulip-UPPOADocument", event.target.files[0]);
    } else if (event.target.id == "SAC") {
      this.setState(
        {
          SAC: event.target.files[0].name,
          SACDocument: fileExtension === "pdf" ? event.target.files[0] : null,
        },
        () => {
          if (fileExtension === "pdf") {
            let SACSize = this.state.SACDocument.size;
            SACSize = (SACSize * 0.0000009537).toPrecision(2);
            this.setState({
              SACErr:
                this.state.SAC.length >= 1 && !(SACSize > 3) ? false : true,
              SACErrMsg:
                SACSize > 3
                  ? "The file exceeds the maximum upload size(3MB) limit"
                  : "",
            });
          } else {
            this.setState({
              SACErr: true,
              SACErrMsg: "Please upload valid file format(PDF)!",
            });
          }
        }
      );
      sessionStorage.setItem("ulip-UPSACDocument", event.target.files[0]);
    } else if (event.target.id == "DDOUseCase") {
      this.setState(
        {
          DDOUseCase: event.target.files[0].name,
          DDOUseCaseDocument:
            fileExtension === "pdf" ? event.target.files[0] : null,
        },
        () => {
          if (fileExtension === "pdf") {
            let DDOSize = this.state.DDOUseCaseDocument.size;
            DDOSize = (DDOSize * 0.0000009537).toPrecision(2);
            this.setState({
              DDOUseCaseErr:
                this.state.DDOUseCase.length >= 1 && !(DDOSize > 3)
                  ? false
                  : true,
              DDOErrMsg:
                DDOSize > 3
                  ? "The file exceeds the maximum upload size(3MB) limit"
                  : "",
            });
          } else {
            this.setState({
              DDOUseCaseErr: true,
              DDOErrMsg: "Please upload valid file format(PDF)!",
            });
          }
        }
      );
      sessionStorage.setItem(
        "ulip-UPDDOUseCaseDocument",
        event.target.files[0]
      );
    }
  };

  enableNextSection = () => {
    sessionStorage.setItem("ulip-UPEnableDataTable", "true");
    const data = {
      POADocument: this.state.POADocument,
      SACDocument: this.state.SACDocument,
      DDOUseCaseDocument: this.state.DDOUseCaseDocument,
    };
    this.props.enableDataTableSection();
    this.props.documentUpload(
      this.state.POADocument,
      this.state.SACDocument,
      this.state.DDOUseCaseDocument
    );
    
  };

  render() {
    return (
      <>
        <div
          className={"CompanyDocumentMainDiv mt-3"}
          style={{ opacity: this.props.enableDataTable ? 0.4 : 1 }}
        >
          <p className={"CompanyDocumentTitle mb-4"}>
            <Badge badgeContent={2} color="primary" className="mr-4"></Badge>{" "}
            Upload Mandatory Documents
          </p>
          <Grid container md={12} className={"mainFormGrid mb-2"} spacing={1}>
            <Grid item md={4} className="pt-0 subEachFieldGrid">
              <label
                htmlFor="my-input"
                className="mb-n5 pt-0 registerFormLabels"
                id="registerFieldInputs"
              >
                Power Of Attorney(Company Authority)
              </label>
              <TextField
                // id="POA"
                variant="outlined"
                margin="normal"
                size="small"
                autoComplete="off"
                // type='file'
                height="0.4em"
                read-only
                placeholder="Browse or Drop files here"
                fullWidth
                title={this.state.POA}
                value={this.state.POA}
                onChange={this.onBrowseFile}
                onClick={() => document.getElementById("POA").click()}
                className={
                  "registerUploadFieldStyle uploadField mt-1 mb-2 pr-0"
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <div
                        disabled
                        className={"cloudIconDiv m-2"}
                        style={{ boxShadow: "0px 3px 6px #00000029" }}
                      >
                        <input
                          type="file"
                          value=""
                          accept="application/pdf"
                          onChange={this.onBrowseFile}
                          id="POA"
                          style={{
                            display: "none",
                            boxShadow: "0px 3px 6px #00000029",
                          }}
                        />
                      </div>

                      <img
                        src={CloudUploadIcon}
                        height={38}
                        className="AttachIcon"
                      />
                    </InputAdornment>
                  ),
                }}
              />
              {this.state.POAErr && (
                <p className="text-danger">{this.state.POAErrMsg}</p>
              )}
              {this.state.POA.length >= 1 && !this.state.POAErr && (
                <Grid
                  className={"previewMainGrid p-1 mb-3"}
                  style={{ display: "flex" }}
                >
                  <DescriptionIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                  />
                  <p
                    className={"m-0 mr-1 filePreviewName"}
                    title={this.state.POA}
                  >
                    {this.state.POA}
                  </p>
                  <CancelIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                    onClick={() => {
                      this.setState({
                        POA: "",
                      });
                    }}
                  />
                </Grid>
              )}
            </Grid>
            <Grid item md={4} className="pt-0 subEachFieldGrid">
              <label
                htmlFor="my-input"
                className="mb-n5 pt-0 registerFormLabels"
                id="registerFieldInputs"
              >
                Security Assessment Certificate
              </label>
              <TextField
                // id="companyProfile"
                variant="outlined"
                margin="normal"
                size="small"
                autoComplete="off"
                // type='file'
                height="0.4em"
                read-only
                placeholder="Browse or Drop files here"
                fullWidth
                title={this.state.SAC}
                value={this.state.SAC}
                onChange={this.onBrowseFile}
                onClick={() => document.getElementById("SAC").click()}
                className={
                  "registerUploadFieldStyle uploadField mt-1 mb-2 pr-0"
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <div
                        className={"m-2"}
                        style={{ boxShadow: "0px 3px 6px #00000029" }}
                      >
                        <input
                          value=""
                          type="file"
                          accept="application/pdf"
                          onChange={this.onBrowseFile}
                          id="SAC"
                          style={{
                            display: "none",
                            boxShadow: "0px 3px 6px #00000029",
                          }}
                        />
                      </div>

                      <img
                        disabled
                        src={CloudUploadIcon}
                        height={38}
                        className="AttachIcon"
                      />
                    </InputAdornment>
                  ),
                }}
              />
              {this.state.SACErr && (
                <p className="text-danger">{this.state.SACErrMsg}</p>
              )}
              {this.state.SAC.length >= 1 && !this.state.SACErr && (
                <Grid
                  className={"previewMainGrid p-1 mb-3"}
                  style={{ display: "flex" }}
                >
                  <DescriptionIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                  />
                  <p
                    className={"m-0 mr-1 filePreviewName"}
                    title={this.state.SAC}
                  >
                    {this.state.SAC}
                  </p>
                  <CancelIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                    onClick={() => {
                      this.setState({
                        SAC: "",
                      });
                    }}
                  />
                </Grid>
              )}
            </Grid>
            <Grid item md={4} className="pt-0 subEachFieldGrid">
              <label
                htmlFor="my-input"
                className="mb-n5 pt-0 registerFormLabels"
                id="registerFieldInputs"
              >
                Detailed Deck On The Use Case(PDF)
              </label>
              <TextField
                // id="DDOUseCase"
                variant="outlined"
                margin="normal"
                size="small"
                autoComplete="off"
                // type='file'
                height="0.4em"
                read-only
                placeholder="Browse or Drop files here"
                fullWidth
                title={this.state.DDOUseCase}
                value={this.state.DDOUseCase}
                onChange={this.onBrowseFile}
                onClick={() => document.getElementById("DDOUseCase").click()}
                className={
                  "registerUploadFieldStyle uploadField mt-1 mb-2 pr-0"
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <div
                        className={"m-2"}
                        style={{ boxShadow: "0px 3px 6px #00000029" }}
                      >
                        <input
                          value=""
                          type="file"
                          accept="application/pdf"
                          onChange={this.onBrowseFile}
                          id="DDOUseCase"
                          style={{
                            display: "none",
                            boxShadow: "0px 3px 6px #00000029",
                          }}
                        />
                      </div>

                      <img
                        src={CloudUploadIcon}
                        height={38}
                        className="AttachIcon"
                      />
                    </InputAdornment>
                  ),
                }}
              />
              {this.state.DDOUseCaseErr && (
                <p className="text-danger">{this.state.DDOErrMsg}</p>
              )}
              {this.state.DDOUseCase.length >= 1 && !this.state.DDOUseCaseErr && (
                <Grid
                  className={"previewMainGrid p-1 mb-3"}
                  style={{ display: "flex" }}
                >
                  <DescriptionIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                  />
                  <p
                    className={"m-0 mr-1 filePreviewName"}
                    title={this.state.DDOUseCase}
                  >
                    {this.state.DDOUseCase}
                  </p>
                  <CancelIcon
                    style={{ color: "#D2000E" }}
                    fontSize="small"
                    onClick={() => {
                      this.setState({
                        DDOUseCase: "",
                      });
                    }}
                  />
                </Grid>
              )}
            </Grid>
          </Grid>
          <Grid className="companyDetailsSubmitBtnDiv">
            <Button
              type="button"
              disabled={
                this.state.POA == "" ||
                this.state.DDOUseCase == "" ||
                this.state.SAC == ""
              }
              className={"companyDetailsSubmitBtn mt-2 mr-2"}
              onClick={this.enableNextSection}
            >
              Save & Next
            </Button>
          </Grid>
        </div>
      </>
    );
  }
}

export default CompanyDocuments;
