import React, { Component } from "react";
import "./css/Login.css";
import {
  AppBar,
  makeStyles,
  Grid,
  Typography,
  Button,
  TextField,
  InputAdornment,
  IconButton,
  FormControlLabel,
  Checkbox,
} from "@material-ui/core";
import MailIcon from "@material-ui/icons/Mail";
import PersonIcon from "@material-ui/icons/Person";
import Divider from "@material-ui/core/Divider";
import VpnKeyIcon from "@material-ui/icons/VpnKey";
import VisibilityIcon from "@material-ui/icons/Visibility";
import VisibilityOffIcon from "@material-ui/icons/VisibilityOff";
// import ulipIllustration from './img/ulip_ilustration.png'
import ulipIllustration from "./img/updatedImage.gif";

import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import submitImg from "./img/submitted.svg";
import ulipLogo from "./img/ulip_logo.png";
import logo from "./img/background_illustration.svg";
import classNames from "classnames";
import { withStyles } from "@material-ui/core/styles";
import { apiRequest } from "../Service";

// import Rating from '@material-ui/lab/Rating';

const drawerWidth = 250;
const styles = (theme) => ({
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    color: "black",
    background: "#005291 0% 0% no-repeat padding-box",
    boxShadow: "0px 6px 13px #00000057",
    // opacity: 0.88,
    height: "50px",
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
});
const UlipImpact = [
  {
    id: 1,
    title: "6",
    subTitle: "Ministeries",
  },
  {
    id: 2,
    title: "24",
    subTitle: "Systems",
  },
  {
    id: 3,
    title: "1454",
    subTitle: "Fields",
  },
  {
    id: 4,
    title: "78",
    subTitle: "APIs",
  },
];
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userID: localStorage.getItem("ulip-UPUser"),
      tempPwd: "",
      allFieldFilled: true,
      PwdTypePwd: "text",
      createPwdTypePwd: "password",
      createPwd: "",
      confirmPwdTypePwd: "password",
      confirmPwd: "",
      confirmPwdEmptyFieldErr: false,
      tempPwdIconStatus: "#CFCFCF",
      createPwdIconStatus: "#CFCFCF",
      confirmPwdIconStatus: "#CFCFCF",
      userIDIconStatus: "#CFCFCF",

      createPwdOutlineStatus: "1px solid #CFCFCF ",
      tempPwdOutlineStatus: "1px solid #CFCFCF ",
      confirmPwdOutlineStatus: "1px solid #CFCFCF ",
      userIdOutlineStatus: "1px solid #CFCFCF ",

      open: true,
      value: 0,
      registerActiveStep: 1,
      isRegisterActive: true,
      UlipImpact: UlipImpact,
      enableNextStep: false,
      termConditionsAccepted: true,
      dialogOpen: false,
      isPasswordGeneratedErr: false,
    };
    // this.onEmailChange = this.onEmailChange.bind(this)
    // this.ontempPwdChange = this.ontempPwdChange.bind(this)
    this.onULoginSubmit = this.onULoginSubmit.bind(this);
    this.onCreatePwdChange = this.onCreatePwdChange.bind(this);
    this.onTextFieldFocus = this.onTextFieldFocus.bind(this);
    this.onTextFieldsBlur = this.onTextFieldsBlur.bind(this);
  }
  onTextFieldFocus = (e) => {
    if (e.target.id == "tempPwd") {
      this.setState({
        tempPwdIconStatus: "#005291",
        tempPwdOutlineStatus: "1px solid #005291 ",
      });
    } else if (e.target.id == "createPwd") {
      this.setState({
        createPwdIconStatus: "#005291",
        createPwdOutlineStatus: "1px solid #005291 ",
      });
    } else if (e.target.id == "confirmPwd") {
      this.setState({
        confirmPwdIconStatus: "#005291",
        confirmPwdOutlineStatus: "1px solid #005291 ",
      });
    } else if (e.target.id == "userID") {
      this.setState({
        userIDIconStatus: "#005291",
        userIdOutlineStatus: "1px solid #005291 ",
      });
    }
  };
  onTextFieldsBlur = (e) => {
    if (e.target.id == "tempPwd") {
      this.setState({
        tempPwdIconStatus: "#CFCFCF",
        tempPwdOutlineStatus: "1px solid #CFCFCF ",
      });
    }
    if (e.target.id == "createPwd") {
      this.setState({
        createPwdIconStatus: "#CFCFCF",
        createPwdOutlineStatus: "1px solid #CFCFCF ",
      });
    } else if (e.target.id == "confirmPwd") {
      this.setState({
        confirmPwdIconStatus: "#CFCFCF",
        confirmPwdOutlineStatus: "1px solid #CFCFCF ",
      });
    } else if (e.target.id == "userID") {
      this.setState({
        userIDIconStatus: "#CFCFCF",
        userIdOutlineStatus: "1px solid #CFCFCF ",
      });
    }
  };
  componentDidMount() {
    // let address = document.location.search;
    // console.log("address", address);
    // let parameterList = new URLSearchParams(address);
    // console.log("parameterList", parameterList);
    // let map = new Map();
    // parameterList.forEach((value, key) => {
    //   map[key] = value;
    // });
    // console.log("map", map);
    // localStorage.setItem("ulip-UPUserID", map["userid"]);
    // localStorage.setItem("ulip-UPUser", map["emailid"]);
    // this.setState(
    //   {
    //     userID: map["emailid"],
    //   },
    //   () => {
    //     var uri = window.location.toString();
    //     if (uri.indexOf("?") > 0) {
    //       var clean_uri = uri.substring(0, uri.indexOf("&"));
    //       window.history.replaceState({}, document.title, clean_uri);
    //     }
    //   }
    // );

    // window.location.search = "";
  }
  onCreatePwdChange = (e) => {
    // alert("Hi")
    console.log(e);
    if (e.target.id == "createPwd") {
      this.setState(
        {
          createPwd: e.target.value,
        },
        () => {
          if (!this.state.createPwd.length) {
            this.setState({
              createPwdErr: false,
            });
          }
        }
      );
    } else if (e.target.id == "confirmPwd") {
      this.setState(
        {
          confirmPwd: e.target.value,
        },
        () => {
          if (!this.state.confirmPwd.length) {
            this.setState({
              confirmPwdErr: false,
            });
          }
        }
      );
    }
  };

  onULoginSubmit = (e) => {
    e.preventDefault();
    // let emailFormat = /^[a-zA-Z0-9.\s@]+@[^\s@]+\.[^\s@]+$/
    let emailFormat = /^[A-Za-z0-9]+(.|_)+[A-Za-z0-9]+@+[A-Za-z].com$/;
    let usernameFormat = /^(?!\d+$)(?:[a-zA-Z0-9][a-zA-Z0-9 @&$]*)?$/;
    let tempPwdFormat = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;

    // if (this.state.createPwd.length == 0 && this.state.confirmPwd.length == 0) {
    //   localStorage.setItem('ulip-UPLoggedIn', true)
    //   window.location.reload()
    // } else {
    this.setState(
      {
        createPwdErr: tempPwdFormat.test(this.state.createPwd) ? false : true,
      },
      async () => {
        if (!this.state.createPwdErr) {
          if (this.state.createPwd == this.state.confirmPwd) {
            const api = "insert_login";
            const formData = new FormData();
            formData.append("userid", localStorage.getItem("ulip-UPUserID"));
            formData.append("emailid", this.state.userID);
            formData.append("password", this.state.createPwd);
            const response = await apiRequest(api, formData);
            console.log(response.data);
            if (response.data.status == "success") {
              this.setState(
                {
                  isPasswordGeneratedErr: false,
                },
                () => {
                  // localStorage.setItem("ulip-UPUser", this.state.userID);
                  // localStorage.setItem("ulip-UPLoggedIn", "true");
                  // localStorage.setItem("ulip-UPUser", this.state.userID);
                  window.location.reload();
                }
              );
            } else {
              this.setState({
                isPasswordGeneratedErr: true,
              });
            }
          } else {
            this.setState({
              confirmPwdErr: true,
            });
          }
        } else {
          this.setState({
            createPwdErr: true,
          });
        }
      }
    );
    // }
  };

  render() {
    const { classes, theme } = this.props;

    return (
      <div id="registerMainDiv">
        <Dialog
          className={"dialogMain p-2"}
          open={this.state.dialogOpen}
          onClose={() => {
            this.setState({ dialogOpen: false });
          }}
          aria-labelledby="form-dialog-title"
        >
          <DialogContent
            className={"p-4"}
            style={{ textAlignLast: "center", width: "300px" }}
          >
            <img src={submitImg} />
            <p className={"m-0 mt-1 submittedText"}>Details Submitted</p>
            <p className={"m-0 mt-1 submittedSubText"}>
              Username and password creation link will be sent to successful
              applicants whose profile accepted by authorities.
            </p>
            <p className={"m-0 mt-2 sequenceID"}>Sequence ID: #07102021</p>
            <Button
              className={"checkMailBtn mt-2"}
              onClick={this.onCheckMailClick}
            >
              Okay, I will check my email
            </Button>
          </DialogContent>
        </Dialog>
        <AppBar
          position="sticky"
          className={classes.appBar}
          fooJon={classNames(classes.appBar, {
            [classes.appBarShift]: this.state.open,
          })}
          id="firstPreHeaderMainDiv"
        >
          <Grid container className="col-md-11 firstPreHeaderContentDiv">
            <img src={ulipLogo} className={"ULIPLogoImg"} />
          </Grid>
        </AppBar>
        <Grid container md={12} id="registerBodyMainDiv">
          <Grid md={6} item className="imageDiv">
            <img
              src={logo}
              width={"620px"}
              height={"530px"}
              img-fluid
              className="logoSideImg"
            />
            <Grid
              md={12}
              item
              className={"ulipImpactGrid carousel-caption mb-2"}
            >
              <img src={ulipIllustration} width={390} height={390} />
              <p className={"ulipImpactMainTitle mb-0 ml-3"}>
                How Unified Logistics Interface Platform Creates An Impact
              </p>
              <Grid md={12} className={"m-2"} style={{ display: "flex" }}>
                {this.state.UlipImpact.map((item, itemIndex) => (
                  <Grid item md={3} className={"ulipImpactSubGrid m-2"}>
                    <p className={"ulipImapactTitle m-0"}>{item.title}</p>
                    <p className={"ulipImapactSubTitle"}>{item.subTitle}</p>
                  </Grid>
                ))}
              </Grid>
            </Grid>

            {/* <p className="carousel-caption">Some text here </p> */}
          </Grid>
          <Grid md={6} item className={"MainTabsGrid"}>
            <Grid className={"subTabsGrid ml-4 mt-5"}>
              <div className={"ULoginFormMainDiv col-md-11 m-4"}>
                <p className={"ULoginFormTitle"}>
                  Login To Data Request Platform
                </p>
                <p
                  style={
                    this.props.onFirstRegister
                      ? { display: "block" }
                      : { display: "none" }
                  }
                  className="text-danger"
                >
                  Your account will be activated in 48hrs.
                </p>
                <div>
                  <form className={"ULoginForm"} onSubmit={this.onULoginSubmit}>
                    <Grid
                      container
                      spacing={2}
                      className={"ULoginFieldsMainGrid"}
                    >
                      <Grid item md={12} className={"ULoginFormEachField"} id="ULoginFormEachFieldID">
                        <label className={"ULoginFormLabels"}>
                          User ID or Email ID
                        </label>
                        <TextField
                          variant="outlined"
                          type={"text"}
                          margin="normal"
                          fullWidth
                          id="userID"
                          autoComplete="off"
                          size="small"
                          read-only
                          autofill
                          value={this.state.userID}
                          className={"ULoginFieldStyle"}
                          style={{
                            outlineColor: this.state.userIdOutlineStatus,
                          }}
                          // onChange={this.onEmailChange}
                          // placeholder='tempPwd'
                          onFocus={this.onTextFieldFocus}
                          onBlur={this.onTextFieldsBlur}
                          name="userID"
                          height="0.4em"
                          InputProps={{
                            startAdornment: (
                              <InputAdornment className={"pl-0"}>
                                <IconButton disabled={true}>
                                  <PersonIcon
                                    style={{
                                      color: this.state.userIDIconStatus,
                                    }}
                                  />
                                  <Divider
                                    className="ml-2"
                                    orientation="vertical"
                                    flexItem
                                  />
                                </IconButton>
                              </InputAdornment>
                            ),
                          }}
                        />
                        <p
                          className="text-danger p-0 m-0"
                          severity="error"
                          style={
                            this.state.emailErr
                              ? { display: "flex" }
                              : { display: "none" }
                          }
                        >
                          {" "}
                          Please provide valid organization mail id!
                        </p>
                      </Grid>

                      <Grid item md={12} className={"ULoginFormEachField"}>
                        <label className={"ULoginFormLabels"}>
                          Create a Password
                        </label>
                        <TextField
                          variant="outlined"
                          type={this.state.createPwdTypePwd}
                          margin="normal"
                          fullWidth
                          id="createPwd"
                          autoComplete="off"
                          size="small"
                          aria-readonly
                          value={this.state.createPwd}
                          className={"ULoginFieldStyle"}
                          style={{
                            outlineColor: this.state.createPwdOutlineStatus,
                          }}
                          onChange={this.onCreatePwdChange}
                          onFocus={this.onTextFieldFocus}
                          onBlur={this.onTextFieldsBlur}
                          placeholder="********"
                          name="createPwd"
                          height="0.4em"
                          InputProps={{
                            startAdornment: (
                              <InputAdornment className={"pl-0"}>
                                <IconButton disabled={true}>
                                  <VpnKeyIcon
                                    style={{
                                      color: this.state.createPwdIconStatus,
                                    }}
                                  />
                                  <Divider
                                    className="ml-2"
                                    orientation="vertical"
                                    flexItem
                                  />
                                </IconButton>
                              </InputAdornment>
                            ),
                            endAdornment: (
                              <InputAdornment>
                                <IconButton
                                  style={{ outline: "none" }}
                                  onClick={() => {
                                    this.setState({
                                      createPwdTypePwd:
                                        this.state.createPwdTypePwd ==
                                        "password"
                                          ? "text"
                                          : "password",
                                    });
                                  }}
                                >
                                  {this.state.createPwdTypePwd == "password" ? (
                                    <VisibilityOffIcon
                                      style={{
                                        color: this.state.createPwdIconStatus,
                                      }}
                                    />
                                  ) : (
                                    <VisibilityIcon
                                      style={{
                                        color: this.state.createPwdIconStatus,
                                      }}
                                    />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            ),
                          }}
                        />
                        <p
                          className="text-danger p-0 m-0"
                          severity="error"
                          style={
                            this.state.createPwdErr
                              ? { display: "flex" }
                              : { display: "none" }
                          }
                        >
                          Must contain at least one number and one uppercase and
                          lowercase letter, and at least 8 or more characters
                        </p>
                      </Grid>
                      <Grid item md={12} className={"ULoginFormEachField"}>
                        <label className={"ULoginFormLabels"}>
                          Confirm a Password
                        </label>
                        <TextField
                          variant="outlined"
                          type={this.state.confirmPwdTypePwd}
                          margin="normal"
                          fullWidth
                          id="confirmPwd"
                          autoComplete="off"
                          size="small"
                          aria-readonly
                          value={this.state.confirmPwd}
                          className={"ULoginFieldStyle"}
                          style={{
                            outlineColor: this.state.confirmPwdOutlineStatus,
                          }}
                          onChange={this.onCreatePwdChange}
                          onFocus={this.onTextFieldFocus}
                          onBlur={this.onTextFieldsBlur}
                          placeholder="********"
                          name="confirmPwd"
                          height="0.4em"
                          InputProps={{
                            startAdornment: (
                              <InputAdornment className={"pl-0"}>
                                <IconButton disabled={true}>
                                  <VpnKeyIcon
                                    style={{
                                      color: this.state.confirmPwdIconStatus,
                                    }}
                                  />
                                  <Divider
                                    className="ml-2"
                                    orientation="vertical"
                                    flexItem
                                  />
                                </IconButton>
                              </InputAdornment>
                            ),
                            endAdornment: (
                              <InputAdornment>
                                <IconButton
                                  style={{ outline: "none" }}
                                  onClick={() => {
                                    this.setState({
                                      confirmPwdTypePwd:
                                        this.state.confirmPwdTypePwd ==
                                        "password"
                                          ? "text"
                                          : "password",
                                    });
                                  }}
                                >
                                  {this.state.confirmPwdTypePwd ==
                                  "password" ? (
                                    <VisibilityOffIcon
                                      style={{
                                        color: this.state.confirmPwdIconStatus,
                                      }}
                                    />
                                  ) : (
                                    <VisibilityIcon
                                      style={{
                                        color: this.state.confirmPwdIconStatus,
                                      }}
                                    />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            ),
                          }}
                        />
                        <p
                          className="text-danger p-0 m-0"
                          severity="error"
                          style={
                            this.state.confirmPwdErr
                              ? { display: "flex" }
                              : { display: "none" }
                          }
                        >
                          Password match the above one!
                        </p>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      md={12}
                      className={["UFormLoginBtnEnableGrid", "mt-4"]}
                    >
                      <Button
                        type={"submit"}
                        // disabled={
                        //   ((this.state.createPwd.length >= 1 &&
                        //     this.state.createPwd.length < 8) ||
                        //     (this.state.confirmPwd.length >= 1 &&
                        //       this.state.confirmPwd.length < 8) ||
                        //     !this.state.createPwd.length ||
                        //     !this.state.confirmPwd.length) &&
                        //   !this.state.userID.length
                        //     ? true
                        //     : false
                        // }
                        className={"UFormLoginBtnEnable"}
                      >
                        Save & Login
                      </Button>
                      {this.state.isPasswordGeneratedErr && (
                        <p className="text-danger p-0 mt-2" severity="error">
                          Internal Server Error!
                        </p>
                      )}
                    </Grid>
                  </form>
                </div>
              </div>
            </Grid>
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default withStyles(styles, { withTheme: true })(Login);
