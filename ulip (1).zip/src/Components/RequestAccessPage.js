import React, { Component } from "react";
import "./css/RequestAccessPage.css";
import {
  AppBar,
  makeStyles,
  Grid,
  Typography,
  Button,
  TextField,
  InputAdornment,
  IconButton,
  FormControlLabel,
  Checkbox,
  Divider,
} from "@material-ui/core";
import searchIcon from "./img/search.svg";
import InputBase from "@material-ui/core/InputBase";
import { withStyles } from "@material-ui/core/styles";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import BottomNavigation from "@material-ui/core/BottomNavigation";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import submitImg from "./img/submitted.svg";
import CompanyDetails from "./CompanyDetails";
import CompanyDocuments from "./CompanyDocuments";
import Badge from "@material-ui/core/Badge";
import * as JSONdata from "./tableData.json";
import { apiRequest } from "../Service";
import { CookieSharp, ThirtyFpsOutlined } from "@mui/icons-material";

const styles = (theme) => ({
  heading: {
    textAlign: "left",
    font: "normal normal normal 18px/27px Poppins",
    letterSpacing: "0px",
    color: "#FFFFFF",
    opacity: 1,
    alignSelf: "center",
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary,
  },
  ExpansionPanel: {
    background: "#009DBB 0% 0% no-repeat padding-box",
    borderRadius: "5px",
    opacity: 1,
  },
  expandIcon: {
    color: "white",
  },
  ExpansionPanelDetails: {
    display: "flex",
    flexFlow: "wrap",
    background: "#FFFFFF 0% 0% no-repeat padding-box",
    boxShadow: "0px 3px 6px #00000029",
    borderRadius: "5px",
    opacity: 1,
  },
});

class RequestAccessPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: null,
      data: JSONdata.data,
      enableDataRequest: false,
      selectedTableColumns: [],
      dialogOpen: false,
      submitRequestAPIErr: false,
      mandatoryDocuments: null,
      POADocument: null,
      SACDocument: null,
      DDOUseCaseDocument: null,
      currentRequestID: "",
      enableDataTable: false,
    };
    this.handleChange = this.handleChange.bind(this);
    this.onColumnSelect = this.onColumnSelect.bind(this);
    this.onSubmitDataRequest = this.onSubmitDataRequest.bind(this);
    this.onCheckAccessGrantedStatus =
      this.onCheckAccessGrantedStatus.bind(this);
    this.enableDataTableSection = this.enableDataTableSection.bind(this);
    this.getColumns = this.getColumns.bind(this);
    this.getRequestCount = this.getRequestCount.bind(this);
  }

  componentDidMount() {
    // this.setState(
    //   {
    //     selectedTableColumns: JSON.parse(
    //       sessionStorage.getItem("ulip-UPRequestedData")
    //     ),
    //   });
  }

  onCheckAccessGrantedStatus = () => {
    this.setState({ dialogOpen: false }, () => {
      sessionStorage.setItem("ulip-UPEnableDataTable", "false");
      this.props.onSubmitDataRequest(this.state.requestData);
      this.props.iconUpdate();
    });
  };

  documentUpload = (POADocument, SACDocument, DDOUseCaseDocument) => {
    this.setState({ POADocument: POADocument });
    this.setState({ SACDocument: SACDocument });
    this.setState({ DDOUseCaseDocument: DDOUseCaseDocument });
  };

  onSubmitDataRequest = async () => {
    this.props.enableLoader(true);
    this.setState({ submitRequestAPIErr: false });
    let tempSelectedTableColumns = [...this.state.selectedTableColumns];
    let payload_data = null;
    tempSelectedTableColumns.map((eachRequest, requestIndex) => {
      if (eachRequest.req_id == "dummy") {
        Object.keys(eachRequest.json_data).map((eachTable, tableIndex) => {
          Object.keys(eachRequest.json_data[eachTable]).map((eachCol, colIndex) => {
            eachRequest.json_data[eachTable][eachCol] = "submitted";
          })
        })
        payload_data = eachRequest.json_data;
        console.log("payload_data",payload_data);
      }
    });
    const api = "submitrequest";
    const formData = new FormData();
    formData.append("userid", localStorage.getItem("ulip-UPUserID"));
    formData.append(
      "pay_load",
      JSON.stringify(payload_data)
    );
    formData.append("emailid", localStorage.getItem("ulip-UPUser"));
    formData.append("POADocument", this.state.POADocument);
    formData.append("SACDocument", this.state.SACDocument);
    formData.append("DDOUseCaseDocument", this.state.DDOUseCaseDocument);
    const response = await apiRequest(api, formData);
    setTimeout(() => {
      this.props.enableLoader(false);
    }, 1500);
    if (response.data.status === "success") {
      this.setState({
        dialogOpen: true,
        currentRequestID: response.data.RequestID,
      });
      sessionStorage.setItem(
        "ulip-UPRequestCount",
        JSON.parse(sessionStorage.getItem("ulip-UPRequestCount")) + 1
      );
      sessionStorage.setItem(
        "ulip-UPTableData",
        JSON.stringify(this.state.data)
      );
      sessionStorage.setItem("ulip-UPRequestedColumns", JSON.stringify({}));
    } else {
      this.setState({ submitRequestAPIErr: true });
    }
  };

  onColumnSelect = (tableIndex, colIndex) => {
    let tempData = this.state.data;
    let newRequestExist = false;
    let tempSelectedTableColumns = this.state.selectedTableColumns != undefined ? [...this.state.selectedTableColumns] : [];    
    tempSelectedTableColumns != undefined && tempSelectedTableColumns.map((eachRequest, requestIndex) => {
      if (eachRequest.req_id == "dummy") {
        console.log("eachRequest.req_id == 'dummy'");
        newRequestExist = true;
        if (
          eachRequest.json_data.hasOwnProperty(
            Object.keys(tempData)[tableIndex]
          )
        ) {
          console.log(
            "eachRequest.json_data.hasOwnProperty(Object.keys(tempData)[tableIndex])",
            eachRequest.json_data.hasOwnProperty(
              Object.keys(tempData)[tableIndex]
            )
          );
          if (
            eachRequest.json_data[
              Object.keys(tempData)[tableIndex]
            ].hasOwnProperty(
              tempData[Object.keys(tempData)[tableIndex]][colIndex]
            )
          ) {
            console.log(
              "eachRequest.json_data[Object.keys(tempData)[tableIndex]].hasOwnProperty(tempData[Object.keys(empData)[tableIndex]][colIndex])"
            );
            delete eachRequest.json_data[Object.keys(tempData)[tableIndex]][
              tempData[Object.keys(tempData)[tableIndex]][colIndex]
            ];
            Object.keys(
              eachRequest.json_data[Object.keys(tempData)[tableIndex]]
            ).length == 0 &&
              delete eachRequest.json_data[Object.keys(tempData)[tableIndex]];
          } else {
            console.log(
              "Else : eachRequest.json_data[Object.keys(tempData)[tableIndex]].hasOwnProperty(tempData[Object.keys(tempData)[tableIndex]][colIndex])"
            );

            Object.assign(
              eachRequest.json_data[Object.keys(tempData)[tableIndex]],
              {
                [tempData[Object.keys(tempData)[tableIndex]][colIndex]]:
                  "selected",
              }
            );
          }
        } else {
          console.log(
            "Else : eachRequest.json_data.hasOwnProperty(Object.keys(tempData)[tableIndex])"
          );
          Object.assign(eachRequest["json_data"], {
            [Object.keys(tempData)[tableIndex]]: {},
          });
          Object.assign(
            eachRequest["json_data"][Object.keys(tempData)[tableIndex]],
            {
              [tempData[Object.keys(tempData)[tableIndex]][colIndex]]:
                "selected",
            }
          );
        }
      }
    });

    if (newRequestExist == false) {
      console.log("newRequestExist", newRequestExist);
      let tempObjOfSelectedColumns = {};
      tempObjOfSelectedColumns["req_id"] = "dummy";
      tempObjOfSelectedColumns["json_data"] = {};
      console.log(
        "Object.keys(tempData)[tableIndex]",
        Object.keys(tempData)[tableIndex]
      );
      Object.assign(tempObjOfSelectedColumns["json_data"], {
        [Object.keys(tempData)[tableIndex]]: {},
      });
      console.log(tempObjOfSelectedColumns);
      Object.assign(
        tempObjOfSelectedColumns["json_data"][
          Object.keys(tempData)[tableIndex]
        ],
        {
          [tempData[Object.keys(tempData)[tableIndex]][colIndex]]: "selected",
        }
      );
      tempSelectedTableColumns.push(tempObjOfSelectedColumns);
      console.log("tempSelectedTableColumns", tempSelectedTableColumns);
    }

    tempSelectedTableColumns.map((eachRequest, requestIndex) => {
      if (eachRequest.req_id == "dummy") {
        this.setState({
          enableDataRequest: Object.keys(eachRequest.json_data).length
            ? true
            : false,
        });
      }
    });

    this.setState({ selectedTableColumns: tempSelectedTableColumns }, () => {
      console.log(
        "on tempselectedTabeColumns set",
        this.state.selectedTableColumns
      );
    });
  };

  handleChange = (panel) => (event, expanded) => {
    this.setState({
      expanded: expanded ? panel : false,
    });
  };

  enableDataTableSection = () => {
    this.setState({
      enableDataTable: true,
    });
  };

  getColumns = (eachTableNameIndex, eachColIndex) => {
    let status = 0;
    this.state.selectedTableColumns != undefined && this.state.selectedTableColumns.map((eachRequest, requestIndex) => {
      console.log("eachRequest", eachRequest);
      console.log(
        "Object.keys(this.state.data)[eachTableNameIndex]",
        Object.keys(this.state.data)[eachTableNameIndex]
      );
      console.log(
        "eachRequest.json_data.hasOwnProperty(Object.keys(this.state.data)[eachTableNameIndex])",
        eachRequest.json_data.hasOwnProperty(
          Object.keys(this.state.data)[eachTableNameIndex]
        )
      );
      console.log(
        "this.state.data[Object.keys(this.state.data)[eachTableNameIndex]][eachColIndex]",
        this.state.data[Object.keys(this.state.data)[eachTableNameIndex]][
          eachColIndex
        ]
      );
      if (
        eachRequest.json_data.hasOwnProperty(
          Object.keys(this.state.data)[eachTableNameIndex]
        )
      ) {
        if (
          eachRequest.json_data[
            Object.keys(this.state.data)[eachTableNameIndex]
          ].hasOwnProperty(
            this.state.data[Object.keys(this.state.data)[eachTableNameIndex]][
              eachColIndex
            ]
          )
        ) {
          let colVal =
            eachRequest.json_data[
              Object.keys(this.state.data)[eachTableNameIndex]
            ][
              this.state.data[Object.keys(this.state.data)[eachTableNameIndex]][
                eachColIndex
              ]
            ];
          if (colVal == "selected") {
            status = 2;
          } else if (
            colVal == "submitted" ||
            colVal == "rejected" ||
            colVal == "approved"
          ) {
            status = 1;
          }
          return;
        }
      }
    });

    return (
      <FormControlLabel
        style={{
          cursor: status == 1 ? "none" : "pointer",
          pointerEvents: status == 1 && "none",
        }}
        disabled={status == 1 ? true : false}
        className={"tableFormControlCheckbox mb-0"}
        control={
          <Checkbox
            onClick={() => {
              this.onColumnSelect(eachTableNameIndex, eachColIndex);
            }}
            checked={status == 1 || status == 2 ? true : false}
            disabled={status == 1 ? true : false}
          />
        }
        label={
          <label
            id="tableColumnName"
            onClick={() => {
              this.onColumnSelect(eachTableNameIndex, eachColIndex);
            }}
            className={
              status == 1 || status == 2
                ? "mb-0 selectedTableColumnName"
                :
              "mb-0 deselectedTableColumnName"
            }
          >
            {
              this.state.data[Object.keys(this.state.data)[eachTableNameIndex]][
                eachColIndex
              ]
            }
          </label>
        }
      />
    );
  };

  getRequestCount = (eachTableNameIndex) => {
    let requestCount = 0;
    this.state.selectedTableColumns != undefined && 
    this.state.selectedTableColumns.map((eachRequest, requestIndex) => {
      if (
        eachRequest.json_data.hasOwnProperty(
          Object.keys(this.state.data)[eachTableNameIndex]
        )
      ) {
        requestCount =
          requestCount +
          Object.keys(
            eachRequest.json_data[
              Object.keys(this.state.data)[eachTableNameIndex]
            ]
          ).length;
      }
    });

    return requestCount > 0 ? (
      <Typography className={"heading"}>
        {Object.keys(this.state.data)[eachTableNameIndex] +
          "(" +
          requestCount +
          ")"}
      </Typography>
    ) : (
      <Typography className={"heading"}>
        {Object.keys(this.state.data)[eachTableNameIndex]}
      </Typography>
    );
  };

  render() {
    const { classes } = this.props;
    const { expanded } = this.state;
    let x = 0;
    return (
      <>
        <div className={"requestAccessMain p-3"}>
          <Dialog
            className={"requestAccessDialogMain p-2"}
            open={this.state.dialogOpen}
            aria-labelledby="form-dialog-title"
          >
            <DialogContent
              className={"p-4"}
              style={{ textAlignLast: "center", width: "300px" }}
            >
              <img src={submitImg} />
              <p className={"mb-0 mt-1 submittedText"}>Request Submitted</p>
              <p className={"mb-0 mt-1 submittedSubText"}>
                Someone from review and approval team will reach out to you.
              </p>
              <p className={"m-0 mt-2 sequenceID"}>
                Request ID: {this.state.currentRequestID}
              </p>
              <Button
                className={"checkMailBtn mt-2"}
                onClick={this.onCheckAccessGrantedStatus}
              >
                Check Access Granted Status
              </Button>
            </DialogContent>
          </Dialog>
          <p className={"requestAccessMainTitle mb-1"}>Request Data</p>
          <Divider className={"mt-2 mb-3"} />
          <div className="requestPageContent">
            <Grid className={"formFieldsSection"}>
              <Grid
                md={12}
                className={"companyDetailsMainGrid"}
              >
                <CompanyDetails />
              </Grid>
              <Grid
                md={12}
                disabled={this.state.enableDataTable ? true : false}
                className={"companyDocuments"}
              >
                <CompanyDocuments
                  enableDataTable={this.state.enableDataTable}
                  enableDataTableSection={this.enableDataTableSection}
                  documentUpload={this.documentUpload}
                />
              </Grid>
            </Grid>

            {this.state.enableDataTable && (
              <>
                <Grid
                  md={12}
                  className={"requestAccessSearchFieldMainGrid mt-3"}
                >
                  <Grid md={6} className={"requestAccessSearchFieldTitle"}>
                    <Badge
                      badgeContent={3}
                      color="primary"
                      className="mr-4"
                    ></Badge>{" "}
                    Select The Data Required
                  </Grid>
                  
                </Grid>
                <Divider className={"mt-2 mb-3"} />
                <Grid md={12} className={"expansionPanelMainGrid"}>
                  {Object.keys(this.state.data).map(
                    (eachTableName, eachTableNameIndex) => (
                      <ExpansionPanel
                        key={eachTableNameIndex}
                        className={[
                          "mb-3 expansionPanel",
                          classes.ExpansionPanel,
                        ]}
                        expanded={expanded === eachTableNameIndex}
                        onChange={this.handleChange(eachTableNameIndex)}
                      >
                        <ExpansionPanelSummary
                          className={classes.ExpansionPanelSummary}
                        >
                          <ArrowDropDownIcon
                            className={classes.expandIcon}
                            fontSize={"large"}
                          />
                          {this.getRequestCount(eachTableNameIndex)}
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails
                          className={classes.ExpansionPanelDetails}
                        >
                          {this.state.data[eachTableName].map(
                            (eachCol, colIndex) => (
                              <Grid item className={"m-1"} key={colIndex}>
                                {this.getColumns(eachTableNameIndex, colIndex)}
                              </Grid>
                            )
                          )}
                        </ExpansionPanelDetails>
                      </ExpansionPanel>
                    )
                  )}
                </Grid>
              </>
            )}
          </div>
        </div>
        {this.state.enableDataTable && (
          <div className={"RAFooterNav"}>
            <BottomNavigation
              showLabels="true"
              style={{
                background: "#FFFFFF 0% 0% no-repeat padding-box",
                boxShadow: "3px 3px 15px #00000024",
                opacity: "1",
                justifyContent: "flex-end",
                alignItems: "center",
              }}
              className={"pr-4 pl-4"}
            >
              {this.state.submitRequestAPIErr && (
                <p className="m-0 mr-3 errMsg">An internal server error occurred. Please try again!</p>
              )}
              <Button
                variant="contained"
                size="large"
                id="submitDetails"
                onClick={this.onSubmitDataRequest}
                disabled={!this.state.enableDataRequest}
                style={{ color: "white" }}
                className={
                  this.state.enableDataRequest
                    ? "enableDataRequest"
                    : "disableDataRequest"
                }
              >
                Submit Data Request
              </Button>
            </BottomNavigation>
          </div>
        )}
      </>
    );
  }
}

export default withStyles(styles, { withTheme: true })(RequestAccessPage);
