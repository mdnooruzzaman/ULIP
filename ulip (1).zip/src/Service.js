import axios from "axios";

export const  apiRequest = async (api, formData, contentType='multipart/form-data') => {
  console.log(formData);
  const config = {
    headers: { 'content-type': contentType, "Access-Control-Allow-Origin": "*" }
  };
  const response = await axios.post(window['getConfig'].API_URL + api, formData, config);
  // console.log("Response----------------", response)
  return response;
};

//http://192.168.99.38/ulip/
//http://127.0.0.1:5000/







