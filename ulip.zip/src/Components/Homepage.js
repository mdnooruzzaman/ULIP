import React, { Component } from "react";
import "./css/Homepage.css";
import { AppBar, Grid } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import classNames from "classnames";
import InputBase from "@material-ui/core/InputBase";
import { Navbar, Image, Nav, NavDropdown } from "react-bootstrap";
import profileImg from "./img/user_profile.svg";
import RequestAccessPage from "./RequestAccessPage";
import AccessGrantedPage from "./AccessGrantedPage";

import AccessGrantedActiveIcon from "./img/access_granted_active_undone.svg";
import AccessGrantedInActiveIcon from "./img/access_granted_inactive.svg";
// import AccessGrantedActiveDoneIcon from "./img/access_granted_active_done.svg";

import RequestAccessActiveIcon from "./img/request_access_active.svg";
import RequestAccessInactiveIcon from "./img/request_access_inactive.svg";
// import RequestAccessInactiveIcon from "./img/request_access_inactive_done.svg";

import ulipLogo from "./img/ulip_logo.png";
import userProfile from "./img/user_inactive.svg";
import logOut from "./img/logOut.svg";
// import UserProfile from "./UserProfile";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import Backdrop from "@mui/material/Backdrop";
import { ThirteenMp } from "@mui/icons-material";

const drawerWidth = 250;

const BootstrapInput = withStyles((theme) => ({
  input: {
    position: "relative",
    //   backgroundColor: theme.palette.background.paper,
    fontSize: 16,
    textAlign: "left",
    font: "normal normal normal 14px/20px Lato",
    letterSpacing: "0px",
    color: "white",
    opacity: "1",
    height: "auto",
    // Use the system font instead of the default Roboto font.

    //   '&:focus': {
    //     borderRadius: 4,
    //     borderColor: '#80bdff',
    //     boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
    //   },
  },
}))(InputBase);

const styles = (theme) => ({
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    color: "black",
    background: "#005291 0% 0% no-repeat padding-box",
    // boxShadow: '0px 6px 13px #00000057',
    // opacity: 0.88,
    height: "50px",
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  appBar2: {
    // zIndex: theme.zIndex.drawer + 1,
    backgroundColor: "white",
    color: "black",
    marginTop: "50px",
    boxShadow: "0px 0px 5px #00000057",
    padding: "8px 12px",
  },
  appBarShift2: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  root: {
    // padding: '2px 4px',
    display: "flex",
    borderRadius: "5px",
    height: "40px",
    // alignItems: 'center',
    // width: 400
  },
  input: {
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  iconButton: {
    padding: 10,
  },
  drawer: {
    [theme.breakpoints.up("sm")]: {
      width: drawerWidth,
      flexShrink: 0,
      zIndex: "auto",
    },
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    [theme.breakpoints.down("sm")]: {
      width: 45,
      flexShrink: 0,
    },
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: theme.spacing(5) + 1,
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(7) + 1,
    },
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    marginTop: theme.spacing.unit,
    justifyContent: "flex-end",
    padding: "0 8px",
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing.unit * 3,
  },
  grow: {
    flexGrow: 1,
  },
});

const requestData = {
  numberOfRequests: 0,
  requestedID: "#REQ07102021",
  requestedDate: "07/10/2021",
  status: "Under Review",
  tableData: [],
};

class Homepage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedTab:
        sessionStorage.getItem("ulip-UPSelectedTab") !== null
          ? sessionStorage.getItem("ulip-UPSelectedTab")
          : "access-granted",
      selectedComponent: null,
      accessGrantedIcon: AccessGrantedActiveIcon,
      requestAccessIcon: RequestAccessInactiveIcon,
      isUserProfileSelected: false,
      selectedTableColumns: [],
      requestData: {},
      loader: false,
    };

    this.UPLogout = this.UPLogout.bind(this);
    this.onTabChange = this.onTabChange.bind(this);
    this.goToRequestAccessTab = this.goToRequestAccessTab.bind(this);
    this.goToAccessGrantedTab = this.goToAccessGrantedTab.bind(this);
    this.OpenProfile = this.OpenProfile.bind(this);
    this.onSubmitDataRequest = this.onSubmitDataRequest.bind(this);
    this.iconUpdate = this.iconUpdate.bind(this);
    this.enableLoader = this.enableLoader.bind(this);
  }

  enableLoader = (status) => {
    this.setState({ loader: status });
  };

  componentDidMount() {
    localStorage.setItem('ulip-UPLoggedIn','true')
    this.setState({
      selectedComponent: (
        <AccessGrantedPage
          goToRequestPage={this.goToRequestAccessTab}
          requestInfo={requestData}
          enableLoader={this.enableLoader}
        />
      ),
    });
    if (sessionStorage.getItem("ulip-UPSelectedTab") !== null) {
      if (sessionStorage.getItem("ulip-UPSelectedTab") == "request-access") {
        this.goToRequestAccessTab();
      } else if (
        sessionStorage.getItem("ulip-UPSelectedTab") == "access-granted"
      ) {
        this.goToAccessGrantedTab();
      }
    }
  }

  iconUpdate = (e) => {
    this.setState({
      accessGrantedIcon: AccessGrantedActiveIcon,
      requestAccessIcon: RequestAccessInactiveIcon,
    });
  };

  onSubmitDataRequest = () => {
    console.log("entered onSubmitDataRequest!");
    this.goToAccessGrantedTab();
  };

  OpenProfile = (e) => {
    this.setState({
      // selectedComponent: <UserProfile />,
      isUserProfileSelected: true,
    });
  };

  goToRequestAccessTab = (e) => {
    this.setState(
      {
        selectedTab: "request-access",
        accessGrantedIcon:
          this.state.accessGrantedIcon == AccessGrantedInActiveIcon
            ? AccessGrantedInActiveIcon
            : AccessGrantedInActiveIcon,
        requestAccessIcon:
          this.state.requestAccessIcon == RequestAccessActiveIcon
            ? RequestAccessActiveIcon
            : RequestAccessActiveIcon,
        selectedComponent: (
          <RequestAccessPage
            onSubmitDataRequest={this.onSubmitDataRequest}
            iconUpdate={this.iconUpdate}
            enableLoader={this.enableLoader}
          />
        ),
      },
      () => {
        sessionStorage.setItem("ulip-UPSelectedTab", this.state.selectedTab);
        // alert("elseIfBlock")
        document
          .getElementById("access-granted-main-div")
          .classList.remove("RequestActiveTabClass");
        document
          .getElementById("access-granted-main-div")
          .classList.add("RequestDeActiveTabClass");
        document
          .getElementById("request-access-main-div")
          .classList.remove("RequestDeActiveTabClass");
        document
          .getElementById("request-access-main-div")
          .classList.add("RequestActiveTabClass");
        document
          .getElementById("request-access-txt")
          .classList.remove("DeActiveTabClass");
        document
          .getElementById("request-access-txt")
          .classList.add("ActiveTabClass");
        document
          .getElementById("access-granted-txt")
          .classList.remove("ActiveTabClass");
        document
          .getElementById("access-granted-txt")
          .classList.add("DeActiveTabClass");
      }
    );
  };

  goToAccessGrantedTab = (e) => {
    console.log("goToAccessGrantedTab");
    this.setState(
      {
        selectedTab: "access-granted",
        accessGrantedIcon:
          this.state.accessGrantedIcon == AccessGrantedActiveIcon
            ? AccessGrantedActiveIcon
            : AccessGrantedActiveIcon,
        requestAccessIcon:
          this.state.requestAccessIcon == RequestAccessInactiveIcon
            ? RequestAccessInactiveIcon
            : RequestAccessInactiveIcon,
        selectedComponent: (
          <AccessGrantedPage
            goToRequestPage={this.goToRequestAccessTab}
            requestInfo={this.state.requestData}
            enableLoader={this.enableLoader}
          />
        ),
      },
      () => {
        sessionStorage.setItem("ulip-UPSelectedTab", this.state.selectedTab);
        document
          .getElementById("access-granted-main-div")
          .classList.remove("RequestActiveTabClass");
        document
          .getElementById("access-granted-main-div")
          .classList.add("RequestActiveTabClass");

        document
          .getElementById("request-access-main-div")
          .classList.remove("RequestActiveTabClass");
        document
          .getElementById("request-access-main-div")
          .classList.add("RequestDeActiveTabClass");

        document
          .getElementById("request-access-txt")
          .classList.remove("ActiveTabClass");
        document
          .getElementById("request-access-txt")
          .classList.add("DeActiveTabClass");

        document
          .getElementById("access-granted-txt")
          .classList.remove("DeActiveTabClass");
        document
          .getElementById("access-granted-txt")
          .classList.add("ActiveTabClass");
      }
    );
  };

  onTabChange = (e) => {
    let selectedID = e.target.id;
    if (
      selectedID == "access-granted-main-div" ||
      selectedID == "access-granted-li" ||
      selectedID == "access-granted-img" ||
      selectedID == "access-granted-txt"
    ) {
      this.setState(
        {
          selectedTab: "access-granted",
          accessGrantedIcon:
            this.state.accessGrantedIcon == AccessGrantedActiveIcon
              ? AccessGrantedActiveIcon
              : AccessGrantedActiveIcon,
          requestAccessIcon:
            this.state.requestAccessIcon == RequestAccessInactiveIcon
              ? RequestAccessInactiveIcon
              : RequestAccessInactiveIcon,
          selectedComponent: (
            <AccessGrantedPage
              goToRequestPage={this.goToRequestAccessTab}
              requestInfo={this.state.requestData}
              enableLoader={this.enableLoader}
            />
          ),
        },
        () => {
          sessionStorage.setItem("ulip-UPSelectedTab", this.state.selectedTab);
          document
            .getElementById("access-granted-main-div")
            .classList.remove("RequestActiveTabClass");
          document
            .getElementById("access-granted-main-div")
            .classList.add("RequestActiveTabClass");

          document
            .getElementById("request-access-main-div")
            .classList.remove("RequestActiveTabClass");
          document
            .getElementById("request-access-main-div")
            .classList.add("RequestDeActiveTabClass","mt-3");

          document
            .getElementById("request-access-txt")
            .classList.remove("ActiveTabClass");
          document
            .getElementById("request-access-txt")
            .classList.add("DeActiveTabClass");

          document
            .getElementById("access-granted-txt")
            .classList.remove("DeActiveTabClass");
          document
            .getElementById("access-granted-txt")
            .classList.add("ActiveTabClass");
        }
      );
    } else if (
      selectedID == "request-access-main-div" ||
      selectedID == "request-access-li" ||
      selectedID == "request-access-img" ||
      selectedID == "request-access-txt"
    ) {
      this.setState(
        {
          selectedTab: "request-access",
          accessGrantedIcon:
            this.state.accessGrantedIcon == AccessGrantedInActiveIcon
              ? AccessGrantedInActiveIcon
              : AccessGrantedInActiveIcon,
          requestAccessIcon:
            this.state.requestAccessIcon == RequestAccessActiveIcon
              ? RequestAccessActiveIcon
              : RequestAccessActiveIcon,
          selectedComponent: (
            <RequestAccessPage
              onSubmitDataRequest={this.onSubmitDataRequest}
              iconUpdate={this.iconUpdate}
              enableLoader={this.enableLoader}
            />
          ),
        },
        () => {
          sessionStorage.setItem("ulip-UPSelectedTab", this.state.selectedTab);
          // alert("elseIfBlock")
          document
            .getElementById("access-granted-main-div")
            .classList.remove("RequestActiveTabClass");
          document
            .getElementById("access-granted-main-div")
            .classList.add("RequestDeActiveTabClass");
          document
            .getElementById("request-access-main-div")
            .classList.remove("RequestDeActiveTabClass","mt-3");
          document
            .getElementById("request-access-main-div")
            .classList.add("RequestActiveTabClass");
          document
            .getElementById("request-access-txt")
            .classList.remove("DeActiveTabClass");
          document
            .getElementById("request-access-txt")
            .classList.add("ActiveTabClass");
          document
            .getElementById("access-granted-txt")
            .classList.remove("ActiveTabClass");
          document
            .getElementById("access-granted-txt")
            .classList.add("DeActiveTabClass");
        }
      );
    }
  };

  UPLogout = () => {
    console.log("UPLogout");
    let n = sessionStorage.length;
    while (n--) {
      let key = sessionStorage.key(n);
      sessionStorage.removeItem(key);
    }

    // let m = localStorage.length;
    // while (m--) {
    //   let key = localStorage.key(m);
    //   localStorage.removeItem(key);
    // }
    localStorage.clear();
    localStorage.setItem("ulipuser-loggedout", "true");
    // localStorage.removeItem('UPLoggedIn');
    // localStorage.removeItem('ulip-WebUserMailID');
    // window.location = window['getConfig'].API_URL;
    window.open(window['getConfig'].API_URL,"_self");
    // const formData = new FormData();
    // const response = await apiRequest(api, formData);


    // this.props.userLoginEnable();
    // localStorage.setItem("ulip-UPUser", "");
    // localStorage.setItem("ulip-UPLoggedIn", "false");
    // window.location.reload();
    // localStorage.setItem("ulip-UPLoggedIn", "false");
    // window.location.reload();
  };

  render() {
    const { classes, theme } = this.props;
    return (
      <>
        <div className={"UHomepageMain"}>
          {this.state.loader && (
            <Backdrop
              sx={{
                color: "#fff",
                zIndex: (theme) => theme.zIndex.drawer + 1,
              }}
              open={true}
            >
              {/* <imports.CircularProgress style={{color:"#00B0F0"}} /> */}
              <span className="Loader" />
            </Backdrop>
          )}

          <AppBar
            position="sticky"
            className={classes.appBar}
            fooJon={classNames(classes.appBar, {
              [classes.appBarShift]: this.state.open,
            })}
            id="UHomePreheader"
          >
            <Grid container md={12} className=" UHomePreheader">
              <Grid item md={9} className="ULIPTitle">
                <img src={ulipLogo} className={"ml-5"} />
              </Grid>
              <Grid item md={3}>
                <Grid container style={{ display: "flex" }}>
                  <Grid
                    className={"ml-5 mt-n2"}
                    style={{
                      textAlignLast: "end",
                      color: "white",
                      alignSelf: "center",
                    }}
                    item
                    md={4}
                  >
                    <img src={profileImg} className={"mr-2"} />
                    Welcome,
                  </Grid>
                  <Grid
                    item
                    md={5}
                    className={"ml-2"}
                    style={{ color: "white", alignSelf: "end" }}
                    title={localStorage.getItem("ulip-UPUser").split("@")[0]}
                  >
                    <NavDropdown
                      className="UActiveAccountDropDown pt-1"
                      title={localStorage.getItem("ulip-UPUser").split("@")[0]}
                      id="basic-nav-dropdown"
                    >
                      <NavDropdown.Item 
                      // href={window['getConfig'].API_URL} 
                      onClick={this.UPLogout}

                      >
                        <img src={logOut} className={"mr-1"} /> Logout{" "}
                        <span className="ArrowMark">{">"}</span>
                      </NavDropdown.Item>
                    </NavDropdown>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </AppBar>

          <Grid
            md={12}
            style={{ display: "flex" }}
            className="HomePageContentMainDiv mt-4 ml-3"
          >
            {this.state.isUserProfileSelected ? (
              <></>
            ) : (
              <Grid className="SideBarMainDiv">
                <ul className="SideBarSubDiv">
                  <Grid
                    item
                    onClick={this.onTabChange}
                    id={"access-granted-main-div"}
                    className={"RequestActiveTabClass mb-3"}
                  >
                    <li
                      onClick={this.onTabChange}
                      id={"access-granted-li"}
                      className={"TabsList p-1"}
                    >
                      <img
                        onClick={this.onTabChange}
                        id={"access-granted-img"}
                        src={this.state.accessGrantedIcon}
                        className={"TabIcons"}
                      />
                      <p
                        onClick={this.onTabChange}
                        id={"access-granted-txt"}
                        className={"ActiveTabClass mb-0"}
                      >
                        Access Granted
                      </p>
                    </li>
                  </Grid>
                  <Grid
                    item
                    onClick={this.onTabChange}
                    id={"request-access-main-div"}
                    className={"RequestDeActiveTabClass mt-3"}
                  >
                    <li
                      onClick={this.onTabChange}
                      id={"request-access-li"}
                      className={"TabsList p-1"}
                    >
                      <img
                        src={this.state.requestAccessIcon}
                        id={"request-access-img"}
                        onClick={this.onTabChange}
                        className={"TabIcons"}
                      />
                      <p
                        onClick={this.onTabChange}
                        id={"request-access-txt"}
                        className={"DeActiveTabClass mb-0"}
                      >
                        Request Data
                      </p>
                    </li>
                  </Grid>
                </ul>
              </Grid>
            )}

            <Grid item md={10} className="HomePageBodyMainDiv ml-4 mt-2">
              {this.state.selectedComponent}
            </Grid>
          </Grid>
        </div>
      </>
    );
  }
}

export default withStyles(styles, { withTheme: true })(Homepage);
